<h1>Plates options</h1>

<h3>Shortcode to add news to page</h3>
<code>[platesReg]</code>

<h2>Plate characteristics</h2>