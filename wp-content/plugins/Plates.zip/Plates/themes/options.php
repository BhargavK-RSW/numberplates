<h1>Plates charactersitics</h1>
<div class="chars-block ">
</div>